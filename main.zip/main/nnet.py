import numpy as np
import random

global MUTATION_WEIGHT_MODIFY_CHANCE, MUTATION_ARRAY_MIX_PERC
MUTATION_ARRAY_MIX_PERC = 0.5
MUTATION_WEIGHT_MODIFY_CHANCE = 0.2

class Nnet:

    def __init__(self, num_input, num_hidden, num_output):
        self.num_input = num_input
        self.num_hidden = num_hidden
        self.num_output = num_output
        self.weight_input_hidden = np.random.uniform(-0.5,0.5, size = (self.num_hidden, self.num_input))
        self.weight_hidden_output = np.random.uniform(-0.5,0.5, size = (self.num_output, self.num_hidden))

    def activation_function(self, input_list_1):
        for row in np.nditer(input_list_1,op_flags=['readwrite']):
            row[...] = (1/(1 + np.exp(-1 * row)))
        return input_list_1

    def get_outputs(self, inputs_list):
        inputs_m = np.array(inputs_list,ndmin=2).T
        hidden_inputs = np.dot(self.weight_input_hidden, inputs_m)
        hidden_outputs = self.activation_function(hidden_inputs)
        final_inputs = np.dot(self.weight_hidden_output,hidden_outputs)
        final_outputs = self.activation_function(final_inputs)
        return final_outputs

    def modify_weights(self):
        Nnet.modify_array(self.weight_input_hidden)
        Nnet.modify_array(self.weight_hidden_output)

    def create_mixed_weights(self,net1,net2):
        self.weight_input_hidden = Nnet.get_mix_from_arrays(net1.weight_input_hidden, net2.weight_input_hidden)
        self.weight_hidden_output = Nnet.get_mix_from_arrays(net1.weight_hidden_output, net2.weight_hidden_output)
   
    def modify_array(self,a):
        for x in np.nditer(a, op_flags=['readwrite']):
            if random.random() < MUTATION_WEIGHT_MODIFY_CHANCE:
                x[...] = np.random.random_sample() - 0.5

    def get_mix_from_arrays(self,ar1,ar2):
        total_entries = ar1.size
        num_rows = ar1.shape[0]
        num_cols = ar1.shape[1]
        num_to_take = (total_entries - (int(total_entries * MUTATION_ARRAY_MIX_PERC)))
        
        idx = np.random.choice(np.arange(total_entries), num_to_take, replace=False)

        res = np.random.rand(num_rows, num_cols)

        for row in range(num_rows):
            for col in range(num_cols):
                index = row * num_cols + col
                if index in idx:
                    res[row][col] = ar1[row][col]
                else:
                    res[row][col] = ar2[row][col]
        return res

if __name__ == "__main__":
    inputs = [.31,.12,.41]
    network = Nnet(3,8,8)
    ar1 = np.random.uniform(-.5,.5,size=(3,4))
    print(ar1)
    network.modify_array(ar1)
    print(ar1)

    #print(network.get_outputs(inputs))
